<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "test";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if patient ID is provided
if (!isset($_GET["id"]) || empty($_GET["id"])) {
    die("Patient ID is missing.");
}

$patient_id = $_GET["id"];

// Fetch patient name from database
$sql = "SELECT name FROM patient WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $patient = $result->fetch_assoc();
    $patient_name = $patient["name"];
} else {
    die("Patient not found.");
}

$stmt->close();

$success_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $treatment_date = $_POST["treatment_date"];
    $diagnose = $_POST["diagnose"];
    $description = $_POST["description"];
    $therapy = $_POST["therapy"];
    $price = $_POST["price"];

    // Convert treatment_date to valid MySQL DATETIME format
    $formatted_treatment_date = date('Y-m-d H:i:s', strtotime($treatment_date));

    $sql = "INSERT INTO treatment (patient_id, patient_name, treatment_date, diagnose, description, therapy, price) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isssssd", $patient_id, $patient_name, $formatted_treatment_date, $diagnose, $description, $therapy, $price);

    if ($stmt->execute()) {
        $success_message = "Treatment successfully added!";
        header("Location: patientData.php?id=$patient_id");
        exit();
    } else {
        $success_message = "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Treatment</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-5">
        <h2>Add New Treatment for <?= htmlspecialchars($patient_name) ?></h2>

        <?php if (!empty($success_message)): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success_message) ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Treatment Date & Time</label>
                <input type="datetime-local" class="form-control" name="treatment_date" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Diagnose</label>
                <input type="text" class="form-control" name="diagnose" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea class="form-control" name="description" rows="3" required></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">Therapy</label>
                <input type="text" class="form-control" name="therapy" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Price</label>
                <input type="number" class="form-control" name="price" step="0.01" required>
            </div>

            <button type="submit" class="btn btn-primary">Save Treatment</button>
            <a href="patientData.php?id=<?= htmlspecialchars($patient_id) ?>" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</body>
</html>
