<?php
if (isset($_GET["id"])) {
    $id = $_GET["id"];

    // Database connection variables
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "test";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Start a transaction to ensure atomic operations
    $conn->begin_transaction();

    // Fetch patient_id before deletion
    $stmt = $conn->prepare("SELECT patient_id FROM treatment WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $treatment = $result->fetch_assoc();
        $patient_id = $treatment["patient_id"];
    } else {
        die("No treatment data found.");
    }
    
    $stmt->close();

    // Prepare the delete query
    $stmt = $conn->prepare("DELETE FROM treatment WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        // If delete is successful, reorder IDs (optional step, though not typically necessary)
        $stmt->close();
        $conn->query("SET @new_id = 0");
        $conn->query("UPDATE treatment SET id = (@new_id := @new_id + 1) ORDER BY id");
        $conn->query("ALTER TABLE treatment AUTO_INCREMENT = 1");

        // Commit the transaction
        $conn->commit();

        // Redirect with success
        header("Location: patientData.php?id=$patient_id&success=1");
        exit();
    } else {
        // If deletion fails, rollback the transaction
        $conn->rollback();
        header("Location: patientData.php?id=$patient_id&error=1");
        exit();
    }

    // Close the connection
    $conn->close();
}
?>
