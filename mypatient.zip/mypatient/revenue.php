<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$database = "test";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$startDate = "";
$endDate = "";
$totalRevenue = 0;
$patients = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $startDate = $_POST["start_date"];
    $endDate = $_POST["end_date"];

    if (!empty($startDate) && !empty($endDate)) {
        // Get total revenue within selected dates
        $sql = "SELECT SUM(price) AS total FROM treatment WHERE DATE(treatment_date) BETWEEN ? AND ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $startDate, $endDate);
        
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            if ($result && $row = $result->fetch_assoc()) {
                $totalRevenue = $row["total"];
            }
            $stmt->close();
        } else {
            echo "Error executing query: " . $conn->error;
        }

        // Fetch patients who had treatments within the selected date range
        $sql = "SELECT patient_id, patient_name, treatment_date, diagnose, therapy, price 
                FROM treatment WHERE DATE(treatment_date) BETWEEN ? AND ? 
                ORDER BY treatment_date ASC";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $startDate, $endDate);

        if ($stmt->execute()) {
            $result = $stmt->get_result();
            while ($row = $result->fetch_assoc()) {
                $patients[] = $row;
            }
            $stmt->close();
        } else {
            echo "Error executing query: " . $conn->error;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <style>
    h2 {text-align: center;}
    h3 {text-align: center;}
    thead {text-align: center;}
    </style>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Total Treatment Cost</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-5">
        <h2>Total Revenue</h2>
        
        <!-- Date Filter Form -->
        <form method="post" class="mb-4">
            <div class="row">
                <div class="col-md-4">
                    <label>Start Date:</label>
                    <input type="date" class="form-control" name="start_date" value="<?= htmlspecialchars($startDate) ?>" required>
                </div>
                <div class="col-md-4">
                    <label>End Date:</label>
                    <input type="date" class="form-control" name="end_date" value="<?= htmlspecialchars($endDate) ?>" required>
                </div>
                <div class="col-md-4">
                    <label>&nbsp;</label>
                    <button type="submit" class="btn btn-primary d-block">Filter</button>
                </div>
            </div>
        </form>

        <!-- Display Total Revenue -->
        <div class="alert alert-info">
            <?php if ($totalRevenue > 0): ?>
                <strong>Total Revenue: Rp. <?= number_format($totalRevenue, 2) ?></strong>
            <?php else: ?>
                <strong>No revenue found for the selected date range.</strong>
            <?php endif; ?>
        </div>

        <!-- Table for Patients with Treatments -->
        <?php if (!empty($patients)): ?>
            <h3>Patients with Treatment</h3>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Patient ID</th>
                        <th>Patient Name</th>
                        <th>Treatment Date</th>
                        <th>Diagnose</th>
                        <th>Therapy</th>
                        <th>Price (Rp)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($patients as $patient): ?>
                        <tr>
                            <td><?= htmlspecialchars($patient["patient_id"]) ?></td>
                            <td><?= htmlspecialchars($patient["patient_name"]) ?></td>
                            <td><?= htmlspecialchars($patient["treatment_date"]) ?></td>
                            <td><?= htmlspecialchars($patient["diagnose"]) ?></td>
                            <td><?= htmlspecialchars($patient["therapy"]) ?></td>
                            <td><?= number_format($patient["price"], 2) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="text-muted">No treatments found in this date range.</p>
        <?php endif; ?>

        <a href="homepage.php" class="btn btn-success">Back to Dashboard</a>
    </div>
</body>
</html>
