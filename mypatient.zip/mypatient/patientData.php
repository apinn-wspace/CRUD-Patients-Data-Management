<?php
// Database connection variables
$servername = "localhost";
$username = "root";
$password = "";
$database = "test";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the patient ID from the URL
if (!isset($_GET["id"]) || empty($_GET["id"])) {
    die("Patient ID is missing.");
}

$patient_id = $_GET["id"];

// Fetch patient data
$sql = "SELECT * FROM patient WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $name = htmlspecialchars($row["name"]);
    $email = htmlspecialchars($row["email"]);
    $phone = htmlspecialchars($row["phone"]);
    $address = htmlspecialchars($row["address"]);
    $age = htmlspecialchars($row["age"]);
    $registered_at = htmlspecialchars($row["registered_at"]);
} else {
    die("No patient data found.");
}

$stmt->close();

// Fetch treatment records for the patient
$treatment_sql = "SELECT * FROM treatment WHERE patient_id = ? ORDER BY treatment_date DESC";
$treatment_stmt = $conn->prepare($treatment_sql);
$treatment_stmt->bind_param("i", $patient_id);
$treatment_stmt->execute();
$treatment_result = $treatment_stmt->get_result();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <style>
    h2 {text-align: center;}
    h3 {text-align: center;}
    thead {text-align: center;}
    </style>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Data</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-5">
        <h2 class="text-center">Patient Data</h2>

        <!-- Patient Information Table -->
        <table class="table table-bordered">
            <thead class="table-dark">
                <tr>
                    <th>Field</th>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><strong>Name</strong></td>
                    <td><?= $name ?></td>
                </tr>
                <tr>
                    <td><strong>Email</strong></td>
                    <td><?= $email ?></td>
                </tr>
                <tr>
                    <td><strong>Phone</strong></td>
                    <td><?= $phone ?></td>
                </tr>
                <tr>
                    <td><strong>Address</strong></td>
                    <td><?= $address ?></td>
                </tr>
                <tr>
                    <td><strong>Age</strong></td>
                    <td><?= $age ?></td>
                </tr>
                <tr>
                    <td><strong>Registered at</strong></td>
                    <td><?= $registered_at ?></td>
                </tr>
            </tbody>
        </table>

        <h3 class="mt-4">Treatment History</h3>

        <!-- Button to Create New Treatment -->
        <a href="createTreatment.php?id=<?= $patient_id ?>" class="btn btn-primary my-3">Add New Treatment</a>

        <!-- Treatment Records Table -->
        <table class="table table-bordered">
            <thead class="table-dark">
                <tr>
                    <th>Date</th>
                    <th>Diagnose</th>
                    <th>Description</th>
                    <th>Therapy</th>
                    <th>Price (Rp)</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($treatment_result->num_rows > 0) {
                    while ($treatment = $treatment_result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . date('Y-m-d / H:i', strtotime($treatment["treatment_date"])) . "</td>"; // Formatted Date
                        echo "<td>" . htmlspecialchars($treatment["diagnose"]) . "</td>";
                        echo "<td>" . htmlspecialchars($treatment["description"]) . "</td>";
                        echo "<td>" . htmlspecialchars($treatment["therapy"]) . "</td>";
                        echo "<td>Rp. " . number_format($treatment["price"], 2) . "</td>";
                        echo "<td>
                                <a href='editTreatment.php?id=" . $treatment["id"] . "' class='btn btn-warning btn-sm'>Edit</a>
                                <a href='deleteTreatment.php?id=" . $treatment["id"] . "' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure you want to delete this treatment?\")'>Delete</a>
                            </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6' class='text-center'>No treatment records found.</td></tr>";
                }
                ?>
            </tbody>

        </table>

        <a href="homepage.php" class="btn btn-secondary">Back to Patients List</a>
    </div>
</body>
</html>
