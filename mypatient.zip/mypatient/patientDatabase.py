import mysql.connector

def create_table():
    try:
        conn = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',  # Replace with your password if needed
            database='test'
        )
        cursor = conn.cursor()

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS patient (
                id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
                name VARCHAR(255) NOT NULL,
                email VARCHAR(255) NOT NULL UNIQUE,
                phone VARCHAR(20) NULL,
                address VARCHAR(255) NULL,
                age INT,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        conn.commit()
        print("Table 'patient' successfully created!")

    except mysql.connector.Error as err:
        print("Error:", err)

    finally:
        if conn.is_connected():
            cursor.close()
            conn.close()

# Call the function to create the table
create_table()
