<?php
// Database connection variables
$servername = "localhost";
$username = "root";
$password = "";
$database = "test";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = $name = $email = $phone = $address = $age = "";
$php_errormsg = "";
$successMessage = "";

// If the request method is GET, fetch the patient data for editing
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (!isset($_GET["id"]) || empty($_GET["id"])) {
        header("Location: homepage.php");
        exit;
    }

    $id = $_GET["id"];

    // Prepared statement to fetch patient data
    $stmt = $conn->prepare("SELECT * FROM patient WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $name = $row["name"];
        $email = $row["email"];
        $phone = $row["phone"];
        $address = $row["address"];
        $age = $row["age"];
    } else {
        header("Location: homepage.php");
        exit;
    }

    $stmt->close();
}

// If the request method is POST, update the patient data
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST["id"];
    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $phone = trim($_POST["phone"]);
    $address = trim($_POST["address"]);
    $age = trim($_POST["age"]);

    // Check if all fields are filled out
    if (empty($id) || empty($name) || empty($email) || empty($phone) || empty($address) || empty($age)) {
        $php_errormsg = "All fields are required.";
    } else {
        // Use Prepared Statement to update patient data
        $stmt = $conn->prepare("UPDATE patient SET name=?, email=?, phone=?, address=?, age=? WHERE id=?");
        $stmt->bind_param("ssssdi", $name, $email, $phone, $address, $age, $id);

        if ($stmt->execute()) {
            $successMessage = "Patient updated successfully!";
            header("Location: homepage.php");
            exit;
        } else {
            $php_errormsg = "Error updating patient: " . $stmt->error;
        }

        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Patient Data</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-5">
        <h2>Edit Patient Data</h2>

        <?php if (!empty($php_errormsg)): ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong><?= htmlspecialchars($php_errormsg); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if (!empty($successMessage)): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?= htmlspecialchars($successMessage); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Edit patient form -->
        <form method="post">
            <input type="hidden" name="id" value="<?= htmlspecialchars($id); ?>">

            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Name</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="name" value="<?= htmlspecialchars($name); ?>">
                </div>
            </div>

            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Email</label>
                <div class="col-sm-6">
                    <input type="email" class="form-control" name="email" value="<?= htmlspecialchars($email); ?>">
                </div>
            </div>

            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Phone</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="phone" value="<?= htmlspecialchars($phone); ?>">
                </div>
            </div>

            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Address</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="address" value="<?= htmlspecialchars($address); ?>">
                </div>
            </div>

            <div class="row mb-3">
                <label class="col-sm-3 col-form-label">Age</label>
                <div class="col-sm-6">
                    <input type="number" class="form-control" name="age" value="<?= htmlspecialchars($age); ?>">
                </div>
            </div>

            <div class="row mb-3">
                <div class="offset-sm-3 col-sm-3 d-grid">
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
                <div class="col-sm-3 d-grid">
                    <a href="homepage.php" class="btn btn-outline-primary">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</body>
</html>
