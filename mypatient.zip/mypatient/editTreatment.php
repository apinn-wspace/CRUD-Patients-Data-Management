<?php
// Database connection variables
$servername = "localhost";
$username = "root";
$password = "";
$database = "test";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the treatment ID from the URL
if (!isset($_GET["id"]) || empty($_GET["id"])) {
    die("Treatment ID is missing.");
}

$treatment_id = $_GET["id"];

// Fetch treatment data
$sql = "SELECT * FROM treatment WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $treatment_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $treatment = $result->fetch_assoc();
    $diagnose = htmlspecialchars($treatment["diagnose"]);
    $description = htmlspecialchars($treatment["description"]);
    $therapy = htmlspecialchars($treatment["therapy"]);
    $price = htmlspecialchars($treatment["price"]);
    $treatment_date = htmlspecialchars($treatment["treatment_date"]);
} else {
    die("No treatment data found.");
}

$stmt->close();

// Check if form is submitted to update the treatment
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $diagnose = $_POST["diagnose"];
    $description = $_POST["description"];
    $therapy = $_POST["therapy"];
    $price = $_POST["price"];
    $treatment_date = $_POST["treatment_date"]; // Capture the updated date and time

    $update_sql = "UPDATE treatment SET treatment_date = ?, diagnose = ?, description = ?, therapy = ?, price = ? WHERE id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("ssssdi", $treatment_date, $diagnose, $description, $therapy, $price, $treatment_id);
    
    if ($update_stmt->execute()) {
        header("Location: patientData.php?id=" . $treatment["patient_id"]);
        exit();
    } else {
        echo "Error updating treatment: " . $conn->error;
    }

    $update_stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Treatment</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-5">
        <h2>Edit Treatment</h2>
        <form action="editTreatment.php?id=<?= $treatment_id ?>" method="POST">
            <div class="mb-3">
                <label for="treatment_date" class="form-label">Treatment Date & Time</label>
                <input type="datetime-local" class="form-control" id="treatment_date" name="treatment_date" value="<?= date('Y-m-d / H:i', strtotime($treatment_date)) ?>" required>
            </div>

            <div class="mb-3">
                <label for="diagnose" class="form-label">Diagnose</label>
                <input type="text" class="form-control" id="diagnose" name="diagnose" value="<?= $diagnose ?>" required>
            </div>

            <div class="mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea class="form-control" id="description" name="description" required><?= $description ?></textarea>
            </div>

            <div class="mb-3">
                <label for="therapy" class="form-label">Therapy</label>
                <input type="text" class="form-control" id="therapy" name="therapy" value="<?= $therapy ?>" required>
            </div>

            <div class="mb-3">
                <label for="price" class="form-label">Price (Rp)</label>
                <input type="number" class="form-control" id="price" name="price" value="<?= $price ?>" required>
            </div>
            
            <button type="submit" class="btn btn-primary">Update Treatment</button>
        </form>
        <a href="patientData.php?id=<?= $treatment["patient_id"] ?>" class="btn btn-secondary my-3">Back to Patient Data</a>
    </div>
</body>
</html>
