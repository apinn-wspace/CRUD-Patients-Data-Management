<?php
if (isset($_GET["id"])) {
    $id = $_GET["id"];

    // Database connection variables
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "test";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Start a transaction to ensure atomic operations
    $conn->begin_transaction();

    try {
        // Delete related records from treatment table
        $stmt = $conn->prepare("DELETE FROM treatment WHERE patient_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();

        // Delete patient record
        $stmt = $conn->prepare("DELETE FROM patient WHERE id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            $stmt->close();

            // Optional: Reset ID auto-increment sequence
            $conn->query("SET @new_id = 0");
            $conn->query("UPDATE patient SET id = (@new_id := @new_id + 1) ORDER BY id");
            $conn->query("ALTER TABLE patient AUTO_INCREMENT = 1");

            // Commit transaction
            $conn->commit();

            // Redirect with success
            header("Location: /mypatient/homepage.php?success=1");
            exit;
        } else {
            throw new Exception("Failed to delete patient.");
        }
    } catch (Exception $e) {
        $conn->rollback();
        header("Location: /mypatient/homepage.php?error=1");
        exit;
    }

    // Close connection
    $conn->close();
}
?>
